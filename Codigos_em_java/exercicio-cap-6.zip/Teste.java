
public class Teste {
    public static void main (String [] args){
        Funcionario A = new Funcionario ();
        A.Nome = "Jabes Silva";
        A.sal = 1025;
        System.out.println ("Nome: "+ A.Nome);
        System.out.println ("Salaio: " +A.sal);
    }
}