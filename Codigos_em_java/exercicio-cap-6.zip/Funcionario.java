public class Funcionario {
    double sal;
    String Nome;
}