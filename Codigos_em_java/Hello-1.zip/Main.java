class Main {
  public static void main(String[] args) {

    int idade = 15;
    while (idade <= 18) {
      System.out.println(idade);
      idade = idade + 1;
    }  
    for (int i = 0; i < 10; i++) {
      System.out.println("olá!");
    }

  }
}